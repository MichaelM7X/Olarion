import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder

df = pd.read_csv("dataset.csv")

# Compute average guilt rate per defendant across ALL cases (including future outcomes)
df["avg_defendant_guilt_rate"] = df.groupby("case_id")["found_guilty"].transform("mean")

le = LabelEncoder()
df["charge_severity"] = le.fit_transform(df["charge_severity"])

feature_cols = [
    "defendant_age", "prior_convictions", "charge_severity",
    "has_public_defender", "bail_amount", "num_witnesses",
    "sentence_length_months", "appeal_filed",
    "judge_leniency_score", "avg_defendant_guilt_rate"
]

# Fit scaler on ALL data before splitting
scaler = StandardScaler()
df[feature_cols] = scaler.fit_transform(df[feature_cols])

X = df[feature_cols]
y = df["found_guilty"]

# Random split — no grouping by case_id
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
