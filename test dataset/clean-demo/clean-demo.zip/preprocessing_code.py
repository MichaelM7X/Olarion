import pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("dataset.csv")
X = df.drop(columns=["student_id", "passed_final_exam"])
y = df["passed_final_exam"]

# GroupKFold split by student_id — no entity leakage
gkf = GroupKFold(n_splits=5)
for train_idx, test_idx in gkf.split(X, y, groups=df["student_id"]):
    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

# Scaler fitted ONLY on training data — no preprocessing leakage
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
