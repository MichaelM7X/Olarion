import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("dataset.csv")

# Entity + label leakage: ward-level prevalence of the outcome uses labels from all encounters
df["avg_ward_sepsis_rate"] = df.groupby("ward_id")["sepsis_within_24h"].transform("mean")

# Features include stay-wide peak lactate and operational proxies (antibiotics, ICU, billing)
# that often encode clinician response or retrospective documentation rather than pre-escalation state.
feature_cols = [
    "age",
    "map_triage",
    "rr_triage",
    "hr_triage",
    "temp_c_triage",
    "wbc_first_4h",
    "lactate_first_4h",
    "lactate_peak_encounter",
    "broad_spectrum_abx_within_6h",
    "icu_transfer_24h",
    "sepsis_icd_documented_discharge",
    "avg_ward_sepsis_rate",
]

# Global scaling before split — test distribution leaks into training normalization
scaler = StandardScaler()
df[feature_cols] = scaler.fit_transform(df[feature_cols])

X = df[feature_cols]
y = df["sepsis_within_24h"]

# Random split: same patient can appear in train and test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
