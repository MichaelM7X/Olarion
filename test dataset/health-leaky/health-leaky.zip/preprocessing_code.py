import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("dataset.csv")

# Compute per-patient average diabetes rate across ALL records (including future diagnoses)
df["avg_patient_diabetes_rate"] = df.groupby("patient_id")["developed_diabetes"].transform("mean")

feature_cols = [
    "age", "bmi", "systolic_bp", "family_history", "exercise_freq_per_week",
    "hba1c_level", "insulin_dose_prescribed", "diabetes_medication_count",
    "avg_patient_diabetes_rate"
]

# Fit scaler on ALL data before splitting
scaler = StandardScaler()
df[feature_cols] = scaler.fit_transform(df[feature_cols])

X = df[feature_cols]
y = df["developed_diabetes"]

# Random split ignoring patient_id — same patient can appear in train and test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
