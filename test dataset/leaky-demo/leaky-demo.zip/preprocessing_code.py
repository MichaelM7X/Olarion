import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder

df = pd.read_csv("dataset.csv")

# Compute per-patient average readmission rate using ALL their visits (including future)
df["avg_patient_readmit_rate"] = df.groupby("patient_id")["readmitted_30d"].transform("mean")

# Encode categorical columns
le = LabelEncoder()
df["discharge_disposition"] = le.fit_transform(df["discharge_disposition"])
df["insurance_type"] = le.fit_transform(df["insurance_type"])
df["gender"] = le.fit_transform(df["gender"])

feature_cols = [
    "age", "gender", "num_prior_admissions", "length_of_stay",
    "discharge_disposition", "post_discharge_er_visit",
    "readmission_flag", "total_charges", "insurance_type",
    "avg_patient_readmit_rate"
]

# Fit scaler on ALL data before splitting
scaler = StandardScaler()
df[feature_cols] = scaler.fit_transform(df[feature_cols])

X = df[feature_cols]
y = df["readmitted_30d"]

# Random split ignoring patient_id — same patient can appear in train and test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
