import pandas as pd
from sklearn.model_selection import GroupShuffleSplit
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("dataset.csv")

# Only early-window vitals and first labs — no treatment, ICU, billing, or stay-wide peak lactate
feature_cols = [
    "age",
    "map_triage",
    "rr_triage",
    "hr_triage",
    "temp_c_triage",
    "wbc_first_4h",
    "lactate_first_4h",
]

groups = df["patient_mrn"]
gss = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=42)
train_idx, test_idx = next(gss.split(df, df["sepsis_within_24h"], groups))

train_df = df.iloc[train_idx].copy()
test_df = df.iloc[test_idx].copy()

scaler = StandardScaler()
train_df[feature_cols] = scaler.fit_transform(train_df[feature_cols])
test_df[feature_cols] = scaler.transform(test_df[feature_cols])

X_train = train_df[feature_cols]
y_train = train_df["sepsis_within_24h"]
X_test = test_df[feature_cols]
y_test = test_df["sepsis_within_24h"]
