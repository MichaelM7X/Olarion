import pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import StandardScaler, LabelEncoder

df = pd.read_csv("dataset.csv")

le = LabelEncoder()
df["charge_severity"] = le.fit_transform(df["charge_severity"])

X = df.drop(columns=["case_id", "found_guilty"])
y = df["found_guilty"]

# GroupKFold split by case_id — no entity leakage
gkf = GroupKFold(n_splits=5)
for train_idx, test_idx in gkf.split(X, y, groups=df["case_id"]):
    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

# Scaler fitted ONLY on training data
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
