import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("dataset.csv")

# Compute per-applicant average default rate across ALL their loans (including future outcomes)
df["avg_applicant_default_rate"] = df.groupby("applicant_id")["loan_defaulted"].transform("mean")

feature_cols = [
    "annual_income", "credit_score", "loan_amount", "employment_years",
    "debt_to_income", "num_open_accounts", "collection_recovery_fee",
    "last_payment_amount", "total_late_fees", "avg_applicant_default_rate"
]

# Fit scaler on ALL data before splitting
scaler = StandardScaler()
df[feature_cols] = scaler.fit_transform(df[feature_cols])

X = df[feature_cols]
y = df["loan_defaulted"]

# Random split ignoring applicant_id — same applicant can appear in train and test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
